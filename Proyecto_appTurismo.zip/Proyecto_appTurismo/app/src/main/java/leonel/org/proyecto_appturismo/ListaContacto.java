package leonel.org.proyecto_appturismo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Hernandez on 26/05/2016.
 */
public class ListaContacto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_contacto);
    }
}
