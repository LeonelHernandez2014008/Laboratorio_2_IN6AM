/**
 * Created by informatica on 06/05/2016.
 */
module.exports={
    'secret': '12e3413ddb60b4124e405df724cad65d',
    'database':{
        connectionLimit: 10,
        host : 'localhost',
        user : 'root',
        password: '',
        database : 'db_appTurismo'
    }
}